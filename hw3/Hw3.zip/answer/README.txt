Run Instructions

**RUN Make Clean and make in sub directory before testing* 
To test decaf-sym:
cd /answer/decaf-sym 
make clean 
make
Run python check-hw3.py "path to answer/decaf-sym" "path to test cases"

To test expr-codegen 

cd /answer/expr-codegen
make clean 
make 
Run python check-hw3.py "path to answer/expr-codegen" "path to test cases"


